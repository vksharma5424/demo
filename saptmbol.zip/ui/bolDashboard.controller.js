sap.ui.controller("ui.bolDashboard", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf testhyperledger.view1
*/
	onInit: function() {
		var that = this;
		var billsOfladingModel = new sap.ui.model.json.JSONModel({ "results" : [] });
		this.byId("sapBOLPage").setModel(billsOfladingModel);
		$.ajax({
			url : "./model/getBillsOfLading.json",
          method : "GET",
		success: function (data) {
			billsOfladingModel.setData( { "results" : data } );
			that.byId("sapBOLPage").setModel(billsOfladingModel);
		},
		error: function (data){alert("Error")}	
		});
		
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf testhyperledger.view1
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf testhyperledger.view1
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf testhyperledger.view1
*/
//	onExit: function() {
//
//	}
	getColorForTileBasedOnStatus : function ( status) {
		return false;
	},
	fnPress : function (oEvent) {
		this.getView().getParent().to(this.getView().getParent().getPages()[1], "" ,oEvent.getSource().getBindingContext().getProperty());
	},
	fnPressNewBillOfLading : function ( ) {
		this.getView().getParent().to(this.getView().getParent().getPages()[2]);
	},
	handlePressOfButton : function (oEvent) {
		var oPayLoad = {
				"jsonrpc": "2.0",
				"method": "query",
				"params": {
					"type": 1,
					"chaincodeID": {
						"name": "26ae941109f309570390aa580905a052178bee0a1dfe311125fcfb69c489fdb4e1e868dd8af82cf2109f478c6c88ea50eb0301bfeecac4964e95c060e83fb31f"
					},
					"ctorMsg": {
						"function": "read",
						"args": [
							"krish12345"
						]
					},
					"secureContext": "user_type1_0"
				},
				"id": 1
			};
		$.ajax({
			url : "https://6ef780d7a0b1439fb366f3621eff3f22-vp1.us.blockchain.ibm.com:5003/chaincode",
          method : "POST",
          data : JSON.stringify(oPayLoad),
		success: function (data) {
			alert("Success");
				},
		error: function (data){alert("Error")}	
		});
	}
});