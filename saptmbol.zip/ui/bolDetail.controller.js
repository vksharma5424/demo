sap.ui.define([
              "sap/ui/core/mvc/Controller",
              "sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
              "use strict";

              return Controller.extend("ui.bolDetail", {

                             /*          onInit: function() {
                                                          this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                                                         this._oRouter.attachRouteMatched(this.handleRouteMatched, this);
                                           },
                                           handleRouteMatched: function(evt) {
                                                          //Check whether is the detail page is matched.

                                                          if (evt.getParameter("name") !== "menu") {
                                                                        return;
                                                          } else {
                                                                        jQuery.sap.require("jquery.sap.storage");
                                                                        var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
                                                                        var bolno = oStorage.get("myLocalData");
                                                                        var j = 0;
                                                                        var index1 = 0;
                                                                        var obj = this.getView().getModel("first1");
                                                                        for (j = 0; j < obj.oData.food1.length; j++) {
                                                                                      if ((obj.oData.food1[j].BOLNo) === bolno) {
                                                                                                     index1 = j;
                                                                                      }
                                                                        }
                                                                        var newmod = {
                                                                                      recipient: {
                                                                                                     BOL: obj.oData.food1[index1].BOLNo,
                                                                                                     Date: obj.oData.food1[index1].Date,
                                                                                                     orderno: obj.oData.food1[index1].orderno,
                                                                                                     portofload: obj.oData.food1[index1].portofload,
                                                                                                     portofdischarge: obj.oData.food1[index1].portofdischarge,
                                                                                                     carriername: obj.oData.food1[index1].carriername,
                                                                                                     mobileno: obj.oData.food1[index1].mobileno,
                                                                                                     trailerno: obj.oData.food1[index1].trailerno,
                                                                                                     sealno: obj.oData.food1[index1].sealno,
                                                                                                     charges: obj.oData.food1[index1].charges,
                                                                                                     shippername: obj.oData.food1[index1].shippername,
                                                                                                     shipperadd: obj.oData.food1[index1].shipperadd,
                                                                                                     shippercity: obj.oData.food1[index1].shippercity,
                                                                                                     shippercountry: obj.oData.food1[index1].shippercountry,
                                                                                                     shipperphone: obj.oData.food1[index1].shipperphone,
                                                                                                     consname: obj.oData.food1[index1].consname,
                                                                                                     consadd: obj.oData.food1[index1].consadd,
                                                                                                     conscity: obj.oData.food1[index1].carriername,
                                                                                                     conscountry: obj.oData.food1[index1].conscountry,
                                                                                                     consphone: obj.oData.food1[index1].consphone,
                                                                                                     status: obj.oData.food1[index1].status
                                                                                      }
                                                                        };
                                                                        //         obj.oData.food1[index1];
                                                                        var model = new JSONModel(newmod);
                                                                        this.getView().setModel(model, "databol");
                                                                        //           var oModel = new JSONModel();
                                                                        var oModel1 = new JSONModel();
                                                                        //              oModel.loadData("model/data.json");
                                                                        oModel1.loadData("model/food.json");
                                                                        //              this.getView().setModel(oModel, "first");
                                                                        this.getView().setModel(oModel1, "second");

                                                                        /*          var oData = {
                                                                                                     items: [{
                                                                                                                   name: "user1",
                                                                                                                   date: "8/3/14 at 12:30 PM"
                                                                                                     }, {
                                                                                                                   name: "user2",
                                                                                                                   date: "4/3/14 at 4:30 PM"
                                                                                                     }, {
                                                                                                                   name: "user3",
                                                                                                                   date: "10/3/14 at 2:30 PM"
                                                                                                     }, {
                                                                                                                   name: "user4",
                                                                                                                   date: "16/3/14 at 6:30 PM"
                                                                                                     }, {
                                                                                                                   name: "user5",
                                                                                                                   date: "9/3/14 at 12:30 PM"
                                                                                                     }]
                                                                                      };
                                                                                      var omodel2 = new sap.ui.model.json.JSONModel();
                                                                                      omodel2.setData(oData);
                                                                                      this.getView().setModel(omodel2, "third");*/
                             

                             /*                         var oData1 = {
                                                                        lanes: [{
                                                                                      //           id: "0",
                                                                                      //           icon: "sap-icon://order-status",
                                                                                      label: "owner1"
                                                                                                     //           position: 0
                                                                        }, {
                                                                                      //           id: "1",
                                                                                      //           icon: "sap-icon://monitor-payments",
                                                                                      label: "owner2"
                                                                                                     //position: 1
                                                                        }, {
                                                                                      //           id: "2",
                                                                                      //           icon: "sap-icon://payment-approval",
                                                                                      label: "owner3"
                                                                                                     //           position: 2
                                                                        },
                                                                        {
                                                                                      //           id: "2",
                                                                                      //           icon: "sap-icon://payment-approval",
                                                                                      label: "owner4"
                                                                                                     //           position: 2
                                                                        },
                                                                        {
                                                                                      //           id: "2",
                                                                                      //           icon: "sap-icon://payment-approval",
                                                                                      label: "owner5"
                                                                                                     //           position: 2
                                                                        },
                                                                        {
                                                                                      //           id: "2",
                                                                                      //           icon: "sap-icon://payment-approval",
                                                                                      label: "owner6"
                                                                                                     //           position: 2
                                                                        }
                                                                        ]
                                                          };*/

                             //           }
              
                                           
                             /*          var oDataProcessFlowLanesAndNodes = {
                                                          nodes: [{
                                                                        id : "1",
                                                                        lane: "3",
                                                                        state: sap.suite.ui.commons.ProcessFlowNodeState.Positive
                                                          }],
                                                          lanes: [{
                                                                        id: "0",
                                                                        icon: "sap-icon://employee",
                                                                        label: "Fruitexport Brazil",
                                                                        position: 0
                                                          }, {
                                                                        id: "1",
                                                                        icon: "sap-icon://employee",
                                                                        label: "Agricexpimp",
                                                                        position: 1
                                                          }, {
                                                                        id: "2",
                                                                        icon: "sap-icon://employee",
                                                                        label: "Groctrade",
                                                                        position: 2
                                                          }, {
                                                                        id: "3",
                                                                        icon: "sap-icon://employee",
                                                                        label: "Freshmarket",
                                                                        position: 3
                                                          }]
                                           };
                                           var oModelPf1 = new sap.ui.model.json.JSONModel();
                                           var viewPf1 = this.getView();
                                           oModelPf1.setData(oDataProcessFlowLanesAndNodes);
                                           viewPf1.setModel(oModelPf1);
                                           viewPf1.byId("processflow1").updateModel();*/
              onInit: function() {
                             /*          var oModel = new JSONModel();
                                           oModel.loadData("model/data.json");
                                           this.getView().setModel(oModel, "first");
                             */                         var oViewModel = new JSONModel({
                                                                        calory: "Kg"
                                                          });
                                                          this.getView().setModel(oViewModel, "view");
                                                          var that = this;
                                           this.getView().addEventDelegate({
            onBeforeShow : jQuery.proxy(that.onBeforeShow, that) 
            });
                             },
                             onAfterRendering : function() {
                                           var caradd = this.getView().byId("carrieraddress").getText();
                                           var consadd = this.getView().byId("consddress").getText();
                                           var shipadd = this.getView().byId("shipperaddress").getText();
                                           //           alert(caradd);
                                           caradd = caradd.substring(0, 18);
                                           consadd = consadd.substring(0, 18);
                                           shipadd = shipadd.substring(0, 18);
                                           caradd = caradd + "....";
                                           consadd = consadd + "....";
                                           shipadd = shipadd + "....";
                                           this.getView().byId("carrieraddress").setText(caradd);
                                           this.getView().byId("consddress").setText(consadd);
                                           this.getView().byId("shipperaddress").setText(shipadd);
                             },
                             edit: function() {
                                           var oView = this.getView();
                                           var oDialog = oView.byId("Dialog");
                                           // create dialog lazily
                                           if (!oDialog) {
                                                          // create dialog via fragment factory
                                                          oDialog = sap.ui.xmlfragment(oView.getId(), "com.sapdemo2.view.Dialog", this);
                                                          oView.addDependent(oDialog);
                                           }
                                           oDialog.open();
                             },
                             onCloseDialog: function() {
                                           this.getView().byId("Dialog1").close();
                             },
                             onclick: function() {
                                           //           alert("hello");
                                           var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                                           oRouter.navTo("first");
                             },
                             pressnav: function() {
                            this.getView().getParent().to(this.getView().getParent().getPages()[0]);
                             },
                             onBeforeShow : function ( oEvent ) {
                                           // to get json oEvent.data
                                           
                                           var data = oEvent.data;
                                           var oModel = new JSONModel(data);
                                           this.getView().setModel(oModel,"first");
                                           //console.log(data.ownershiptrail.length);
                                           
              }

              });
});
