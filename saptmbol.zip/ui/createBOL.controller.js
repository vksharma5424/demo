sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";
	return Controller.extend("ui.createBOL", {
		_data: {
			"date": new Date()
		},
		onBeforeShow: function(){
               this.getView().byId("BoLNo").setValue("");
               this.getView().byId("orderNo").setValue("");
               this.getView().byId("dateOfLoading").setValue("");
               this.getView().byId("dateOfDischarge").setValue("");
               this.getView().byId("loadingPort").setValue("");
               this.getView().byId("dischargePort").setValue("");
               this.getView().byId("freightCharge").setValue("");
               this.getView().byId("carrierName").setValue("");
               this.getView().byId("carrierAddress").setValue("");
               this.getView().byId("carrierCity").setValue("");
               this.getView().byId("carrierState").setValue("");
               this.getView().byId("carrierZip").setValue("");
               this.getView().byId("carrierContact").setValue("");
               this.getView().byId("carrierCountry").setValue("");
               this.getView().byId("shipperName").setValue("");
               this.getView().byId("shipperAddress").setValue("");
               this.getView().byId("shipperCity").setValue("");
               this.getView().byId("shipperState").setValue("");
               this.getView().byId("shipperZip").setValue("");
               this.getView().byId("shipperCountry").setValue("");
               this.getView().byId("shipperContact").setValue("");
               this.getView().byId("consigneeName").setValue("");
               this.getView().byId("consigneeAddress").setValue("");
               this.getView().byId("consigneeCity").setValue("");
               this.getView().byId("consigneeState").setValue("");
               this.getView().byId("consigneeZip").setValue("");
               this.getView().byId("consigneeCountry").setValue("");
               this.getView().byId("consigneeContact").setValue("");
               var tbl = this.getView().byId("containerdetails");
               var items=tbl.getItems();
               var i,j;
               for(i=0;i<items.length;i++)
               {
                              var cells=items[i].getCells();
                              for(j=0;j<cells.length;j++)
                              {
                                            cells[j].setValue("");
                              }
               }
		},

		onInit: function() {
			var oModel = new JSONModel(this._data);
			var cModel = new JSONModel();
			var dModel = new JSONModel();
			cModel.setSizeLimit(500);
			this.getView().setModel(oModel);
			cModel.loadData("model/countries.json");
			this.getView().setModel(cModel, "Country");
			// dModel.loadData("model/getBillsOfLading.json");
			this.getView().setModel(dModel, "BoL");
			
			var that = this;
			this.getView().addEventDelegate({
            onBeforeShow: jQuery.proxy(that.onBeforeShow, that)
        });
		},
			pressnav: function() {
			this.getView().getParent().to(this.getView().getParent().getPages()[0]);
			},
		create: function() {
			var bolNo = this.getView().byId("BoLNo").getValue();
			var orderNo = this.getView().byId("orderNo").getValue();
			var dateOfLoading = this.getView().byId("dateOfLoading").getValue();
			var dateOfDischarge = this.getView().byId("dateOfDischarge").getValue();
			var loadingPort = this.getView().byId("loadingPort").getValue();
			var dischargePort = this.getView().byId("dischargePort").getValue();
			var freightCharges = this.getView().byId("freightCharge").getSelectedItem().getText();
			var carrierName = this.getView().byId("carrierName").getValue();
			var carrierAddress = this.getView().byId("carrierAddress").getValue();
			var carrierCity = this.getView().byId("carrierCity").getValue();
			var carrierState = this.getView().byId("carrierState").getValue();
			var carrierZip = this.getView().byId("carrierZip").getValue();
			var carrierContactNo = this.getView().byId("carrierContact").getValue();
			var carrierCountry = this.getView().byId("carrierCountry").getSelectedItem().getText();
			var shipperName = this.getView().byId("shipperName").getValue();
			var shipperAddress = this.getView().byId("shipperAddress").getValue();
			var shipperCity = this.getView().byId("shipperCity").getValue();
			var shipperState = this.getView().byId("shipperState").getValue();
			var shipperZip = this.getView().byId("shipperZip").getValue();
			var shipperCountry = this.getView().byId("shipperCountry").getSelectedItem().getText();
			var shipperContactNo = this.getView().byId("shipperContact").getValue();
			var consigneeName = this.getView().byId("consigneeName").getValue();
			var consigneeAddress = this.getView().byId("consigneeAddress").getValue();
			var consigneeCity = this.getView().byId("consigneeCity").getValue();
			var consigneeState = this.getView().byId("consigneeState").getValue();
			var consigneeZip = this.getView().byId("consigneeZip").getValue();
			var consigneeCountry = this.getView().byId("consigneeCountry").getSelectedItem().getText();
			var consigneeContactNo = this.getView().byId("consigneeContact").getValue();
			var tbl = this.getView().byId("container");
			var items = tbl.getItems();
			var date =new Date();
			var i;
			var value = [];
			var k = 0;
			for (i = 0; i < items.length; i++) {
				var cells = items[i].getCells();
				var j;
				for (j = 0; j < cells.length; j++) {
					value[k] = cells[j]["_lastValue"];
					k++;
				}
			}
			var details = {
				"bolno": bolNo,
				"status": "Original",
				"portOfLoading": loadingPort,
				"portOfDischarge": dischargePort,
				"dateOfLoading": dateOfLoading,
				"dateOfDischarge": dateOfDischarge,
				"chargeTerms": freightCharges,
				"shipper": {
					"name": shipperName,
					"address": {
						"line1": shipperAddress,
						"city": shipperCity,
						"state": shipperState,
						"country": shipperCountry,
						"zipcode": shipperZip,
						"contactInfo": {
							"phone": shipperContactNo,
							"email": ""
						}
					}
				},
				"consignee": {
					"name": consigneeName,
					"address": {
						"line1": consigneeAddress,
						"city": consigneeCity,
						"state": consigneeState,
						"country": consigneeCountry,
						"zipcode": consigneeZip,
						"contactInfo": {
							"phone": consigneeContactNo,
							"email": ""
						}
					}
				},
				"carrier": {
					"name": carrierName,
					"address": {
						"line1": carrierAddress,
						"city": carrierCity,
						"state": carrierState,
						"country": carrierCountry,
						"zipcode": carrierZip,
						"contactInfo": {
							"phone": carrierZip,
							"email": ""
						}
					}
				},
				"container": [],
				"ownershiptrail": [{
					"name": shipperName,
					"date": date,
					"address": {
						"line1": shipperAddress,
						"city": shipperCity,
						"state": shipperCity,
						"country": shipperCountry,
						"zipcode": shipperZip
					},
					"isOwner": true
				}],
				"canChangeOwner": true
			};
			var p;
			var q = -1;
			for (p = 0; p < i; p++) {
				var container_item = {
					"ID": value[++q],
					"item": value[++q],
					"totalNo": value[++q],
					"description": value[++q],
					"weight": value[++q],
					"sealNo": value[++q]
				};
				details['container'].push(container_item);

			}
			var oBoL = this.getView().getModel("BoL");
			oBoL.setData(details);
			console.log(oBoL);
			var detailsInJSON = oBoL.getJSON();
			console.log(detailsInJSON);
			
			//To set the modelData of the dashboard view
			var modelData = this.getView().getParent().getPages()[0].byId("sapBOLPage").getModel().getData();
			modelData.results[modelData.results.length] = details;
			this.getView().getParent().getPages()[0].byId("sapBOLPage").getModel().setData(modelData);
			
			this.getView().getParent().to(this.getView().getParent().getPages()[0]);
		},
		cancel: function() {
			this.getView().getParent().to(this.getView().getParent().getPages()[0]);
		},
		deleteRow: function(oEvent) {
			var oTable = this.getView().byId("containerdetails");
			var oItem = oTable.getSelectedItems();
			var i;
			for (i = 0; i < oItem.length; i++) {
				oTable.removeItem(oItem[i]);
			}
		},
		_createNewLine: function(oEvent) {
			var columnListItemNewLine = new sap.m.ColumnListItem({
				type: sap.m.ListType.Inactive,
				SelectionMode: "Single",
				unread: false,
				vAlign: "Middle",
				cells: [
					// add created controls to item
					new sap.m.Input({
						type: "Text"
					}).addStyleClass("inputBoxFormatter"),
					new sap.m.Input({
						type: "Text"
					}).addStyleClass("inputBoxFormatter"),
					new sap.m.Input({
						type: "Number"
					}).addStyleClass("inputBoxFormatter"),
					new sap.m.Input({
						type: "Text"
					}).addStyleClass("inputBoxFormatter"),
					new sap.m.Input({
						type: "Number"
					}).addStyleClass("inputBoxFormatter"),
					new sap.m.Input({
						type: "Number"
					}).addStyleClass("inputBoxFormatter")
				]
			}).addStyleClass("rowFormat");
			return columnListItemNewLine;
		},
		addRow: function(oEvent) {
			var table = this.getView().byId("containerdetails");
			var newLine = this._createNewLine(oEvent, null);
			table.addItem(newLine);
		}
	
	});
});